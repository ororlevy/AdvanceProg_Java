### README ###

# Please exctract all of the files from the zip file and save all of them in the same folder.
# the script in "takeoff.txt" is used fot the first autopilot flight - to let the plane take of.
# the script in "route.txt" is used to let the plane fly in the path that was calculated by the server - please load it after calculating a path.
